# Mantis Free React Material UI Dashboard Template [![Tweet](https://img.shields.io/twitter/url/http/shields.io.svg?style=social)](https://twitter.com/intent/tweet?text=Get%20Mantis%20Free%20React%20-%20The%20Most%20Beautiful%20Material-UI%20Designed%20Admin%20Dashboard%20Template%20&url=https://mantisdashboard.com/free&via=codedthemes&hashtags=react,materialui,nextjs,webdev,developers,typescript)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Price](https://img.shields.io/badge/price-FREE-0098f7.svg)](https://github.com/codedthemes/mantis-free-react-admin-template/blob/master/LICENSE)
[![GitHub package version](https://img.shields.io/github/package-json/v/codedthemes/mantis-free-react-admin-template)](https://github.com/codedthemes/mantis-free-react-admin-template/)
[![Download ZIP](https://img.shields.io/badge/Download-ZIP-blue?style=flat-square&logo=github)](https://codedthemes.com/item/mantis-free-mui-admin-template/)
[![Join Discord](https://img.shields.io/badge/Join-Discord-5865F2?style=flat-square&logo=discord&logoColor=white)](https://discord.com/invite/p2E2WhCb6s)

Mantis is a free and open source React dashboard template made using the Material UI React component library with aim of flexibility and better customizability.

### Name Derived From Nature

Mantis Logo is inspired from the insect name - 'Mantises' as they have triangular heads with flexible Necks. Also, the name is derived from two popular design systems, Material and Ant Design (M-Ant-is).

Mantis has Ant Design principal on top of the Material UI React component library.

✨ Support us! If you like this theme, click the ⭐ (Top right) and let it shine

![mantis-free-react-dashboard-template.jpg](https://org-public-assets.s3.us-west-2.amazonaws.com/Free-Version-Banners/GITHUB-FREE-REACT-REPO+-+Mantis.png)

## Table of contents

- [Getting Started](#getting-started)
- [Download](#download)
- [Why Mantis?](#why-mantis)
- [What's included in Premium Version?](#whats-included-in-premium-version)
- [Documentation](#documentation)
- [Browser support](#browser-support)
- [Technology Stack](#technology-stack)
- [Mantis Figma UI Kit](#mantis-figma-ui-kit)
- [Other Technologies](#other-technologies)
- 💰[Save more with Big Bundle](#save-more-with-big-bundle)💰
- [More React Dashboard Templates](#more-react-dashboard-templates)
- [Issues?](#issues)
- [License](#license)
- [Contributor](#contributor)
- [Useful Resources](#useful-resources)
- [Community](#community)
- [Follow us](#follow-us)

## Getting Started

1. Clone from Github

```
git clone https://github.com/codedthemes/mantis-free-react-admin-template.git
```

2. Install packages

```
yarn
```

3. Run project

```
yarn run start
```

## Download

- Mantis Free
  - [Live Preview](https://mantisdashboard.com/free/)
  - [Download](https://codedthemes.com/item/mantis-free-mui-admin-template/)
- Mantis Pro
  - [Live Preview](https://mantisdashboard.com/)
  - [Download](https://codedthemes.com/item/mantis-mui-react-dashboard-template/)

## Why Mantis?

Mantis offers everything needed to build an advanced dashboard application. In the initial release, we included following high-end features,

- Support React19.
- Professional user interface.
- Material UI React components(MUI v7).
- Fully responsive, all modern browser supported.
- Easy to use code structure
- Flexible & high-Performance code
- Simple documentation

## What's included in Premium Version?

The [Pro version](https://mantisdashboard.com/) of Mantis react template includes features such as TypeScript, apps, authentication methods (i.e. JWT, Auth0, Firebase, AWS, Supabase), advance components, form plugins, layouts, widgets, and more.

| [Mantis Free](https://mantisdashboard.com/free/)                                                     | [Mantis](https://mantisdashboard.com/)                                            |
| ---------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------- |
| **7** Demo pages                                                                                     | **85+** demo pages                                                                |
| -                                                                                                    | ✓ Multi-language                                                                  |
| -                                                                                                    | ✓ Dark/Light Mode 🌓                                                              |
| -                                                                                                    | ✓ TypeScript version                                                              |
| -                                                                                                    | ✓ Design files (Figma)                                                            |
| -                                                                                                    | ✓ Multiple color options                                                          |
| -                                                                                                    | ✓ RTL                                                                             |
| -                                                                                                    | ✓ JWT authentications                                                             |
| -                                                                                                    | ✓ [More components](https://mantisdashboard.com/components-overview/autocomplete) |
| ✓ [MIT License](https://github.com/codedthemes/mantis-free-react-admin-template/blob/master/LICENSE) | ✓ [Pro License](https://mui.com/store/license/)                                   |

## Documentation

[Mantis documentation](https://codedthemes.gitbook.io/mantis) helps you out in all aspects from Installation to deployment.

## Browser support

<img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/chrome.png" width="45" height="45" > <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/edge.png" width="45" height="45" > <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/safari.png" width="45" height="45" > <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/firefox.png" width="45" height="45" > <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/opera.png" width="45" height="45" >

## Technology Stack

- Material UI V7
- Built with React Hooks API.
- React context API for state management.
- SWR.
- React Router for navigation routing.
- Support for Vite.
- Code splitting.
- CSS-in-JS.

## Mantis Figma UI Kit

| FREE                                                                                                                        | PRO                                                                                                                       |
| --------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
|  <a href="https://codedthemes.com/item/mantis-free-figma-ui-kit/" traget="_blank"><img src="https://org-public-assets.s3.us-west-2.amazonaws.com/Banners/Figma_Free_Mantis.png" width="450" alt="Figma Free"></a> | <a href="https://codedthemes.com/item/mantis-figma-ui-kit/" traget="_blank"><img src="https://org-public-assets.s3.us-west-2.amazonaws.com/Banners/Figma_Pro_Mantis.png" width="450" alt="Figma Pro"></a> |

## Other Technologies

| Technology                                                                                                                        | Free                                                                               | Pro                                                                       |
| --------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| <p align="center"><img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Angular.png" width="25" height="25"></p>   | [**Free**](https://codedthemes.com/item/mantis-angular-free-admin-template/)       | [**Pro**](https://codedthemes.com/item/mantis-angular-admin-template/)    |
| <p align="center"><img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Bootstrap.png" width="30" height="30"></p> | [**Free**](https://codedthemes.com/item/mantis-bootstrap-free-admin-template/)     | [**Pro**](https://codedthemes.com/item/mantis-bootstrap-admin-dashboard/) |
| <p align="center"><img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Vue.png" width="25" height="25"></p>       | [**Free**](https://codedthemes.com/item/mantis-free-vuetify-vuejs-admin-template/) | [**Pro**](https://codedthemes.com/item/mantis-vue-admin-template/)        |

## Save more with Big Bundle

[![bundle-image](https://org-public-assets.s3.us-west-2.amazonaws.com/Banners/Bundle+banner.png)](https://links.codedthemes.com/jhFBJ)

## More React Dashboard Templates

| Dashboard                                                                                                                                                          | FREE                                                                                | PRO                                                                                   |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Berry%20with%20name.png"  height="30" style="display:inline-block; vertical-align:middle;">   | [**Free**](https://codedthemes.com/item/berry-mui-free-react-admin-template/)       | [**Pro**](https://codedthemes.com/item/berry-material-react-admin-template/)</span>   |
| <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Datta%20with%20name.png" height="30" style="display:inline-block; vertical-align:middle;">    | [**Free**](https://codedthemes.com/item/datta-able-react-free-admin-template/)      | [**Pro**](https://codedthemes.com/item/datta-able-react-admin-template/)</span>       |
| <img src="https://org-public-assets.s3.us-west-2.amazonaws.com/logos/Gradient%20with%20name.png" height="30" style="display:inline-block; vertical-align:middle;"> | [**Free**](https://codedthemes.com/item/gradient-able-reactjs-free-admin-template/) | [**Pro**](https://codedthemes.com/item/gradient-able-reactjs-admin-dashboard/)</span> |

## Issues

Please generate a [Github issue](https://github.com/codedthemes/mantis-free-react-admin-template/issues) if you found a bug in any version. We are try our best to resolve the issue.

## License

- Licensed under [MIT](https://github.com/codedthemes/mantis-free-react-admin-template/blob/master/LICENSE)
- Copyright © [CodedThemes](https://codedthemes.com/)

## Contributor

**CodedThemes Team**

- https://x.com/codedthemes
- https://github.com/codedthemes

**Rakesh Nakrani**

- https://x.com/rakesh_nakrani

**Brijesh Dobariya**

- https://x.com/dobaria_brijesh

## Useful Resources

- [More Admin Templates From CodedThemes](https://codedthemes.com/item/category/admin-templates/)
- [Freebies From CodedThemes](https://codedthemes.com/item/category/free-templates/)
- [Big Bundles](https://codedthemes.com/item/big-bundle/)
- [Figma UI Kits](https://codedthemes.com/item/category/templates/figma/)
- [Affiliate Program](https://codedthemes.com/affiliate/)
- [Blogs](https://blog.codedthemes.com/)

## Community

- 👥Follow [@codedThemes](https://x.com/codedthemes)
- 🔗Join [Discord](https://discord.com/invite/p2E2WhCb6s)
- 🔔Subscribe to [CodedTheme Blogs](https://blog.codedthemes.com/)

## Follow Us

- [Twitter](https://twitter.com/codedthemes) 🐦
- [Dribbble](https://dribbble.com/codedthemes) 🏀
- [Github](https://github.com/codedthemes) 🐙
- [LinkedIn](https://www.linkedin.com/company/codedthemes/) 💼
- [Instagram](https://www.instagram.com/codedthemes/) 📷
- [Facebook](https://www.facebook.com/codedthemes) 🟦
